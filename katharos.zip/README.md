# Katharos (clean)

## Summary

No magic, no zombies, no luck.

## Description

This project is an effort to make the game more rational and an effort to remove supernatural elements.
It is a resource pack that tries to remove most of the supernatural elements from Minecraft, so that scientific elements can be used instead.

## Important notices

Only US English (en-us) is supported at the moment.

### Supported Minecraft versions

- 1.14.4
- 1.15
- 1.15.1
- 1.15.2
- 1.16-Snapshot
- 1.16
- 1.16.1
- 1.16.2

### Supported mods and custom maps

- Skyblock 4
- MoEnchantments
- Vanilla Hammers
